**To confirm user registration**

This example confirms user jane@example.com.

Command::

  aws cognito-idp admin-confirm-sign-up --user-pool-id us-west-2_aaaaaaaaa --username jane@example.com 
  
