**To delete an endpoint service configuration**

This example deletes the specified endpoint service configuration.

Command::

  aws ec2 delete-vpc-endpoint-service-configurations --service-ids vpce-svc-03d5ebb7d9579a2b3

Output::

 {
    "Unsuccessful": []
 }